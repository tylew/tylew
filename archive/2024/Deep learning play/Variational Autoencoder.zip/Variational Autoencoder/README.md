**Experiment Report on Variational Autoencoder Implementation**

**Name:** Tyler Lewis  
**Student ID:** 2366930

**TO RUN:**
run `autoencoder.py` which will train a model (low compute, ran on laptop in < 3minutes)


**Reference and tools**
Utilized https://avandekleut.github.io/vae/ blog post for reference and support in VAE programming semantics.